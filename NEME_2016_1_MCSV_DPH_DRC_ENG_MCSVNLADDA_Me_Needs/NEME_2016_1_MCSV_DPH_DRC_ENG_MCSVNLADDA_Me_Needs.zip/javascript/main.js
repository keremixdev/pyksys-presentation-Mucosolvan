//drcom.ready([],function(){
drcom.ready([],function(){
	$(".cir1").bind('tapone', function() {
        drcom.gotoSlide(6);
    });	
	$(".cir2").bind('tapone', function() {
        drcom.gotoSlide(7);
    });	
	$(".cir3").bind('tapone', function() {
        drcom.gotoSlide(8);
    });		
});



