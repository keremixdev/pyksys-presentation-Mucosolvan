//drcom.ready([],function(){
drcom.ready([],function(){
	setTimeout(function(){
		$(".txtc_expand").addClass('ani');
		setTimeout(function(){
			$('.txtc_expand p ').show();
		},500)
	},1000)
});



