//drcom.ready([],function(){
drcom.ready([],function(){
	
	setTimeout(function(){
		$('.circle_1').fadeIn(500,function(){
			$('.red_circle').fadeIn(500);
		});
	},500);
	
	
});



