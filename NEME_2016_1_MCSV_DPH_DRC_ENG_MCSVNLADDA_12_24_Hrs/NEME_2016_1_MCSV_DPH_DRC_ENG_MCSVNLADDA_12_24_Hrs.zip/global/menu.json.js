var menudata = [
	{
		"id": 1,
		"path": "0.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Home"
	},
	{
		"id": 2,
		"path": "1.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_HPR"
	},
	{
		"id": 3,
		"path": "2.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_HPA"
	},
	{
		"id": 4,
		"path": "3.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_HPO"
	},
	{
		"id": 5,
		"path": "4.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Me_Needs"
	},
	{
		"id": 6,
		"path": "5.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_12_24_Hrs"
	},
	{
		"id": 7,
		"path": "6.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Sa_Pr"
	},
	{
		"id": 8,
		"path": "7.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_UWA"
	},
	{
		"id": 9,
		"path": "8.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_HPD"
	},
	{
		"id": 10,
		"path": "9.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_PS1"
	},
	{
		"id": 11,
		"path": "10.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_PS2"
	},
	{
		"id": 12,
		"path": "11.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_HPS"
	},
	{
		"id": 13,
		"path": "12.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Ambroxol"
	},
	{
		"id": 14,
		"path": "13.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_SlyticEOA"
	},
	{
		"id": 15,
		"path": "14.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_StoricEOA"
	},
	{
		"id": 16,
		"path": "15.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_ProEOA1"
	},
	{
		"id": 17,
		"path": "16.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_ProEOA2"
	},
	{
		"id": 18,
		"path": "17.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_ProEOA3"
	},
	{
		"id": 19,
		"path": "18.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_ProEOA4"
	},
	{
		"id": 20,
		"path": "19.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_ProEOA5"
	},
	{
		"id": 21,
		"path": "20.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Sum"
	},
	{
		"id": 22,
		"path": "21.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Ref"
	},
	{
		"id": 30,
		"path": "22.0",
		"name": "NEME_2016_1_MCSV_DPH_DRC_ENG_MCSVNLADDA_Sitemap",
		"hideonmenu": true,
		"hideonslide": true
	}
];