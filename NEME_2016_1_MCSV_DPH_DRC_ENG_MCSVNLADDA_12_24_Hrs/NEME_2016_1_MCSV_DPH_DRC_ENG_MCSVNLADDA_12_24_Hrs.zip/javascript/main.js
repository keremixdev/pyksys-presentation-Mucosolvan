//drcom.ready([],function(){
drcom.ready([],function(){
	$(".cir").bind('tapone', function() {
        drcom.gotoSlide(5);
    });	
});